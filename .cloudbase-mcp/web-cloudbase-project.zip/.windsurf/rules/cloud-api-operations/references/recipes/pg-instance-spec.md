# Recipe 3 — PostgreSQL 实例变配与升级独享

## When to use

要让云开发环境的 PostgreSQL 实例改变**租户形态或规格**时：

- 规格撑不住：CPU / 内存打满、慢查询变多，要调大（或调小）实例规格
- 环境用的是**共享** PG，要升级成**独享**实例
- 已经提交了变配 / 升独享，要知道**任务跑完没有、跑到哪、失败原因是什么**
- 变配 / 升独享**还没提交或刚提交**，用户先问「要多久、业务会不会断」—— 这类「给用户的预期」按序列 D 的口径回答，不要自己估
- 用户问「是不是得先升套餐才能升配」「升完每月多花多少」—— 按「费用与套餐」一节的结论与口径回答，不要凭感觉

本篇管 PG 的**实例管控面**：租户形态、规格、存储、异步任务。

- 数据面（建表、跑 SQL、schema、migration）转 `queryPgDatabase` / `managePgDatabase`
- 存储空间告警转 [Recipe 1](./pg-storage-alarm.md)
- 环境套餐（`baas_personal` 这类）的续费 / 升级转 `tcb/ModifyEnvPlan`

## 前置权限

| service | version | 用途 |
| --- | --- | --- |
| `tcb` | `2018-06-08` | 环境的 PG 实例管控面：变配 / 升独享 / 查任务（写） |
| `postgres` | `2017-03-12` | 读实例现状与可售规格 |

**凭据身份：账号级。** 实例挂在云开发环境上，但读它的现状要走 `postgres` 产品接口。`callCloudApi` 有环境绑定门禁，账号级登录后先 `auth(action="set_env", envId=…)` 绑到目标环境；实例不在默认地域时，`postgres` 的读接口要在顶层传 `region`。

权限按凭据身份分开补：

- **账号级身份**（腾讯云密钥 / 子账号 / device 登录）：读实例现状与规格表需要 `QcloudPostgreSQLReadOnlyAccess`；`tcb` 的这几个 Action 属云开发自身能力，一般不额外要策略。**先直接往下做**，只有真的返回 `UnauthorizedOperation` 时才回来补。
- **CLI / MCP 用 TCB 服务角色换临时密钥**：权限挂在角色上，给角色追加同一条策略。

一键授权链接（以 `TCB_QcsRole` 为例，`principal` 是该角色载体的 base64）：

- `https://console.cloud.tencent.com/cam/role/grant?roleName=TCB_QcsRole&policyName=QcloudPostgreSQLReadOnlyAccess&principal=eyJzZXJ2aWNlIjpbInRjYi5jbG91ZC50ZW5jZW50LmNvbSJdfQ%3D%3D`

账号级身份缺权限时，由主账号给**这个身份**追加策略，别去点角色的链接。链接拼法、`principal` 的固定取值与使用边界见 [calling-methods.md §3.2](../calling-methods.md)。

官方接口文档：云开发 API 概览 https://cloud.tencent.com/document/api/876/34809 （请求域名 `tcb.tencentcloudapi.com`）；云数据库 PostgreSQL API 概览 https://cloud.tencent.com/document/api/409/16761 （请求域名 `postgres.tencentcloudapi.com`）。

## 费用与套餐：调规格无套餐门槛，升独享有套餐门槛

**B1 调规格（独享实例）没有套餐门槛。** 调用条件只有两类：实例状态可操作、目标规格合法。没有「套餐档位」「计费模式」这类前置。

🔴 **B2 升独享有套餐门槛，而且是硬门槛**（实测 2026-10-16）。个人版（`baas_personal`）环境调用被直接拒：

```
current package does not support upgrading to dedicated instance
```

同样的参数换到标准版（`baas_pf_standard`）环境就成功升到独享并跑到 `Succeed`。准入范围（内部口径 + 实测一致）：**标准版及以上（标准版 / 企业版 / 企业高级版）+ 集成版 / 平台版**。

门槛的几个反直觉点，别用别处的经验套：

- ⚠️ **不要试图从套餐字段预判**：`ResourceLimit` 里没有 `PostgreSQL.DedicatedInstance` 键并不等于不能升 —— 标准版就没有这个键，照样能升；有这个键的只有企业版 / 企业高级版。`PackageType` 也不可靠：`tcb/DescribeEnvPlans` 与 `manageEnv listPackages` 对同一档位给出的值并不一致。直接调用接口，以返回为准。
- ⚠️ **没有可读的资格字段，也没有 DryRun**：判断某个环境能不能升，只能真调一次；调完没报套餐错就是能升。
- ⚠️ **先复查实例再查套餐**：目标环境如果压根没开 PG，接口先报 `PG instance not found.`，压根走不到套餐那道校验。所以「报错说没实例」和「报错说套餐不行」要分开读，别把没开 PG 讲成套餐问题。
- ⚠️ 选环境时另有坑：`manageEnv listPackages` 按新购页口径只返回 `default` 族，标准版 / 企业版（`basic` 族）不在列表里，但它们合法可建。详见 `cloudbase-platform` skill 的 `manageEnv` 一节。

别把边缘加速那道门槛套到这里。边缘加速确实要求「标准版及以上套餐 + 环境处于资源点计费模式」（见 [Recipe 4](./custom-domain.md)），那是**加速能力**的准入要求；PG 变配是**实例自身**的规格调整，两件事。

费用按**实例规格**扣资源点，与访问量无关（没人连库也照扣）：

| 项 | 口径 |
| --- | --- |
| CPU | **342 资源点 / CU / 小时** |
| 存储 | **0.5 资源点 / GB / 小时** |

按这个口径，2 核 4 GiB + 50 GB 的独享实例是 **709 资源点/小时**（约 1.7 万/天）；从 1 核 2 GiB + 10 GB 升到它，每小时多 362 资源点。控制台提交页的「用量推算」就按这个口径给，细则可以引其中的「PostgreSQL 数据库计量说明」链接给用户。

「要不要升套餐」的判据要分开说：**B1 只看资源点够不够扣**；**B2 先过套餐准入，再看资源点**。B1 升配后消耗变快，扣到不足时才需要升套餐或加购资源包 —— 那是**额度**问题，不是 B1 的前置条件。回答用户时把这两件事分开说，别让「先升套餐」变成一次白忙。

这一节的口径只适用于**独享**实例：共享实例的计费规则不同，升独享提交时的提示就是「升级后按独享实例的计费规则计量计费」。

## 接口序列

### A. 先读现状：这个环境的 PG 是哪种、现在什么规格

| 步 | Action | service / version | 关键参数 | 取什么 |
| --- | --- | --- | --- | --- |
| 1 | DescribeEnvInfo | `tcb` / `2018-06-08` | `{ "EnvId": "<envId>" }` | `EnvBaseInfo.PostgreSQL[].InstanceName`（= 下一步的 `DBInstanceId`）、`.TenantType` |
| 2 | DescribeDBInstanceAttribute | `postgres` / `2017-03-12` | `{ "DBInstanceId": "<上一步的 InstanceName>" }`，地域走顶层 `region` | `DBInstance` 下的 `DBInstanceCpu` / `DBInstanceMemory` / `DBInstanceStorage` / `DBInstanceClass` / `DBMajorVersion` / `DBInstanceStorageType` / `Zone` / `DBInstanceStatus` |

`PostgreSQL` 是数组：空数组说明这个环境没有开 PG，不要在它上面做变配。`TenantType` 是分流开关 —— `SHARED` 走序列 B2 升独享，`DEDICATED` 走序列 B1 调规格。

### B1. 独享实例调规格

| 步 | Action | service / version | 关键参数 | 取什么 |
| --- | --- | --- | --- | --- |
| 3 | DescribeClasses | `postgres` / `2017-03-12` | `{ "Zone": "<A2 的 Zone>", "DBEngine": "postgresql", "DBMajorVersion": "<A2 的 DBMajorVersion>", "StorageType": "<A2 的 DBInstanceStorageType>", "InstanceCategory": "cloudbase" }` | `ClassInfoSet[]`：`SpecCode` / `CPU` / `Memory` / `MinStorage` / `MaxStorage` / `State` |
| 4 | ModifyPGInstanceSpec（预检） | `tcb` / `2018-06-08` | 步骤 5 的全部参数 + `"DryRun": true` | `DealName` / `BillId`（预检通过时都是空串） |
| 5 | ModifyPGInstanceSpec（正式） | `tcb` / `2018-06-08` | `{ "EnvId": …, "Cpu": <核数>, "Memory": <GB>, "SwitchTag": 0\|1\|2, "Storage": <GB，可选> }` | `DealName` / `BillId` |

步骤 3 只从返回列表里挑规格 —— `State` 为 `1` 表示在售；`CPU` / `Memory` 与 `SpecCode` 三列要一致地挑同一行。`Storage` 目标值必须落在该行的 `MinStorage` ~ `MaxStorage` 之间。

步骤 4 是提交前的安全网：`DryRun: true` 只做校验、不发起变配。预检报错就直接改参数重来，**不要跳过预检直接提交**（规格非法时会留下无效订单）。

步骤 5 的 `SwitchTag` 决定切换时机：`0` 立即、`1` 指定时间、`2` 维护时间窗口内。用 `1` 时 `SwitchStartTime` / `SwitchEndTime` 的格式是 **`YYYY-MM-dd HH:mm:ss`**：

```json
{
  "EnvId": "<envId>",
  "Cpu": 2,
  "Memory": 4,
  "Storage": 50,
  "SwitchTag": 0
}
```

返回 `DealName`（账单名）与 `BillId`（账单标识）。**变配是异步的：拿到订单号 ≠ 已经变完**，规格要按序列 C 回查。

### B2. 共享实例升级为独享

| 步 | Action | service / version | 关键参数 | 取什么 |
| --- | --- | --- | --- | --- |
| 6 | DescribeClasses | `postgres` / `2017-03-12` | 同步骤 3，`StorageType` 可以不传 | 同步骤 3 |
| 7 | UpgradePGInstanceToDedicated | `tcb` / `2018-06-08` | `{ "EnvId": …, "SwitchTag": 0\|1, "SpecCode": "<步骤 6 的 SpecCode>", "Storage": <GB> }` | `TaskId` |

`SwitchTag` 是**必填**（`0` 立即切换、`1` 指定时间切换）。用 `1` 时 `SwitchStartTime` / `SwitchEndTime` 的格式是 **`HH:MM:SS`** —— 和 B1 的 `ModifyPGInstanceSpec` **不是同一套格式**。

```json
{
  "EnvId": "<envId>",
  "SwitchTag": 0,
  "SpecCode": "pg.it.small2",
  "Storage": 10
}
```

**B2 有两道硬门槛，不满足会被直接拒掉，且都不产生任何任务。**

**门槛一：套餐。** 只有**标准版及以上（标准版 / 企业版 / 企业高级版）+ 集成版 / 平台版**才授这个能力（详见「费用与套餐」一节）。个人版实测报：

```
current package does not support upgrading to dedicated instance
```

**门槛二：实例形态。** 只接受 **`shared`（多租户共享）** 形态，其它形态报（实测 2026-09-24）：

```
only shared (multi-tenant) instance can be upgraded to dedicated, current form: small_tenant
```

**报错读法：先实例、后套餐。** 三种报错对应三种原因，别混成一句「套餐不行」：

| 报错 | 原因 | 下一步 |
| --- | --- | --- |
| `PG instance not found.` | 环境压根没开 PG（**最先触发**） | 先确认环境是否开通了 PG，与套餐无关 |
| `current package does not support upgrading to dedicated instance` | 有 PG，但套餐不到标准版 | 升套餐到标准版及以上 / 集成版后再试 |
| `only shared (multi-tenant) instance can be upgraded…` | 有 PG、套餐够，但形态不是共享 | 本来就不需要升，如实告诉用户 |

**「云开发侧写着独享」和「PG 侧是什么形态」是两套话。** 实测一个 `DescribeEnvInfo` 里 `TenantType: DEDICATED` 的实例，PG 侧形态是 `small_tenant`，调这个接口被上面第二句拒掉。**实例形态一律按 `DescribeEnvInfo` 的 `TenantType` 判断，不要按套餐名、购买页或环境新旧推断** —— 个人版默认就是**共享（多租户）**形态，「个人版 = 独享」这个印象通常是错的；反过来也确实存在 `DEDICATED` 的实例。

⚠️ **别用「新开的环境就是独享」来省掉序列 A**：实测新建的标准版环境，开出来的 PG 仍然是 `TenantType: SHARED`。

**PG 侧形态字段 `DBTenantType` 有三个取值：**

| 值 | 含义 | 能不能升 |
| --- | --- | --- |
| `tenant` | 共享多租户（可升级形态） | ✅ 实测可升 |
| `small_tenant` | 另一种共享形态 | ❌ 被拒（见上） |
| `instance` | 独享单实例 | 升级完成后就是它 |

手上实例已经是 `DEDICATED` 时，这条链路的正确动作是**不要调**，如实告诉用户它不需要升独享 —— 别把「接口报错」讲成「升级失败」。

返回 `TaskId`，用序列 C 回查进度。

这个接口是**云开发侧对 PG 云 API 的封装**（比 PG 原生多一个 `EnvId` 入参、少一个实例 ID）。控制台代码里把这个接口的两条边界写得很明确，照它做：

- 返回的 `TaskId` **只能**给云开发的 `tcb/DescribeTaskResult`，**不能**拿去调 PG 的 `postgres/DescribeTasks`（两个任务体系不互通）；
- **云开发任务成功 ≠ PG 升级完成** —— 数据库侧的信息以 `postgres/DescribeDBInstanceAttribute` 为准。

所以序列 C 里步骤 8 看到 `Succeed` **不是终点**，还要用步骤 10 确认规格真的变了，别把 `Succeed` 直接当成「升级完成」报给用户。

**任务与耗时（实测 2026-10-16）：**

- 任务详情里 `TaskType` 实测为 **`UpgradePGInstance`**。判读仍只看 `Status` / `Phase` / `Reason`，不要按 `TaskType` 做白名单过滤。
- 任务 `Params` 里带 **`pg_task_id`**（底层 PG 任务号）与 `new_instance_id` —— 两套任务体系其实有映射，但仍然不该拿云开发 `TaskId` 去查 `postgres/DescribeTasks`。
- **没有进度百分比，也没有 ETA 字段**。`Phase` 实测走过 `WaitMigrateDone`，结束时为 `FinishUpgrade`。
- 耗时样本：标准版环境升到 `1 核 2 GiB` + 10 GB（`SwitchTag: 0`），从提交到 `Status = Succeed` 约 **2 分 49 秒**。

**实例状态会经过几个不在别处的收尾态。** 实测顺序：`running` → `migrating` → `switching` → `rest-accessible` → `log-switching`。迁移期间 `DBRestAccessStatus` 为 `inactive`、三个内网地址 `Status: initing`，完成后回 `active`；网络端点会换血（旧的 `jnsgw` 虚拟地址消失，换成真实私有地址，如 `postgresql` 5432 / `postgrest` 3000）。**判完成只看规格字段与 `UpdateTime`，不要拿这些中间态当失败。**

**实例 ID 不一定会变。** 控制台对 `migrated` 的注释是「当前共享 pgdb 实例信息已过时，需重新 `DescribeEnvs` 拿迁移后的新独享实例 ID 再查」，但实测 2026-10-16 这次**全程没出现 `migrated`、ID 也没变**（`new_instance_id == instance_id`）。会变的是 `CreateTime`：升级后它变成提交那一刻 —— 说明底层是新实例**复用了同一个 ID**，不是「变配没生效」。只有当用旧 ID 查到过期信息时才重走序列 A。

### C. 回查：任务、进度与规格

| 步 | Action | service / version | 关键参数 | 取什么 |
| --- | --- | --- | --- | --- |
| 8 | DescribeTaskResult | `tcb` / `2018-06-08` | `{ "EnvId": …, "TaskId": "<B2 的 TaskId>" }` | `Status` / `Phase` / `Reason` / `CreatedAt` / `UpdatedAt` |
| 9 | DescribeTasks | `postgres` / `2017-03-12` | `{ "DBInstanceId": "<A2 的 DBInstanceId>", "Limit": 20, "OrderBy": "StartTime", "OrderByType": "desc" }` | `TaskSet[]` 每条任务的 `TaskType` / `Status` / `Progress` / `StartTime` / `EndTime` / `TaskDetail.AllSteps` / `.CurrentStep` |
| 10 | DescribeDBInstanceAttribute | `postgres` / `2017-03-12` | 同步骤 2 | 规格是否已变成目标值 |

三个入口的分工：

- **升独享（B2）** 返回 `TaskId` → 用步骤 8 看 `Status`（`Accepted` / `Running` / `Succeed` / `Failed`）与 `Phase`，失败读 `Reason`。**这个接口没有进度百分比、也没有预计完成时间。**
- **调规格（B1）不返回任何任务号** → 进度用步骤 9：`TaskSet` 是混排的，先按 `TaskType = "ModifyInstanceSpec"` 且 `StartTime` 最晚的那条定位到本次变配，读它的 `Progress`（0–100）与 `TaskDetail.CurrentStep`。任务结束后再用步骤 10 比对 `DBInstanceCpu` / `DBInstanceMemory` / `DBInstanceStorage`。
- `TaskSet` 里都是**这个实例自己**的任务（含改参、SSL、外网、备份回档等），`TotalCount` 是总数，分页靠 `Limit` / `Offset`。

步骤 9 的 `Limit` 上限 100；不传 `MinStartTime` 时**默认只展示 180 天内**的任务。

想用图形界面看这两条，控制台入口是：PG 实例页 `https://tcb.cloud.tencent.com/dev?envId=<envId>#/db/postgres/setting`（规格），任务列表 `https://tcb.cloud.tencent.com/dev?envId=<envId>#/db/postgres/tasks`。

### D. 给用户的预期提示

用户真正关心的是两件事：**要多久**、**业务会不会断**。这两件事的答案都在控制台已有的口径里，照下面说就行 —— 不要自己估一个数。

#### D1. 会不会断：分三段，只有中间一段有问题

| 阶段 | 业务可访问性 |
| --- | --- |
| 改配 / 数据迁移（`DBInstanceStatus` 为 `expanding` 或 `migrating`） | **正常**。数据库连接不断，SQL 照跑 |
| 最终切换（`waitSwitch` → `switching`） | **一次秒级闪断**。所有连接会被断开一次，客户端重连即可 |
| 完成后 | 正常。**独享调规格后访问地址不变**（IP、端口、连接串都不变） |

控制台在提交前给的告警口径（可以直接转述给用户）：

- **共享升独享**：升级为独享实例后**无法回退**；升级后按独享实例的计费规则计量计费；升级过程中存在**一次秒级的连接中断**，需要确保数据库客户端具备重连能力；建议在**低峰期**执行；实例在调整配置过程中可能会进行数据迁移，**期间实例访问不受影响**。
- **独享调规格**：升级后按新规格计费；同样**一次秒级闪断**；**升级后实例访问地址不会变化**；建议低峰期执行；迁移期间访问不受影响；**存储空间仅支持调大，不支持调小**。

#### D2. 要多久：没有 ETA 字段，用 `Progress` + 历史同类任务实测耗时

云 API 里**没有「预计完成时间」这个字段**，两个任务接口都没有。能给的可靠预期只有两个来源：

1. **当前进度**：步骤 9 的 `Progress`（0–100）与 `TaskDetail.CurrentStep` / `AllSteps`。报「进行到 65%，当前步骤 Execute Switch」远比「应该快好了」有用。
2. **上一轮的真实耗时**：在步骤 9 的 `TaskSet` 里找**同一实例、`TaskType = ModifyInstanceSpec`、`Status = Success`** 的历史记录，`EndTime - StartTime` 就是上次的真实耗时。

同一实例、只改 CPU / 内存、`SwitchTag: 0` 的实测样本（可直接作为量级参考）：

| 方向 | `TaskDetail.AllSteps` | 耗时 |
| --- | --- | --- |
| 1 核 2 GiB → 2 核 4 GiB（升配） | Pre-check → Node configuration change → **Data Synchronization** → **Execute Switch** → Task Complete | **174 秒**（约 3 分钟） |
| 2 核 4 GiB → 1 核 2 GiB（降配） | Pre-check → Node configuration change → **Wait for Restart Completion** → Wait for configuration change to complete → Task Complete | **67 秒**（约 1 分钟） |

两个可复用结论：**升配走「数据同步 + 切换」，降配走「重启」，升配明显更慢**；`AllSteps` 会随任务推进**动态增加**（同一个任务先返回 4 步、中途变成 5 步），不要把它当固定清单。

进度是异步刷新的，报给用户时给区间而不是精确时刻：一分钟量级的变配按「几分钟内」说，迁移型的升独享只报「已提交，正在迁移」并持续轮询。

#### D3. 变配期间不要重复提交

`DBInstanceStatus` 回到 `running`（或 `limited run`）之前，第二次变配会被拒。控制台自己用的是「提交后最长跟踪 30 分钟」：超过 30 分钟还没等到规格变化就不再视为进行中。给用户的说法统一成：**在实例状态回到运行中之前，不要重复发起，也不要手动重启**。

#### D4. 状态判读表

| `DBInstanceStatus` | 含义 | 用户侧影响 |
| --- | --- | --- |
| `running` | 运行中 | 无。可以发起变配 / 升独享 |
| `expanding` | 变配中（含数据迁移阶段） | 连接正常、SQL 可跑；不要重复提交 |
| `migrating` | 共享升独享迁移中 | 连接正常、SQL 可跑 |
| `migrated` | 迁移完成，实例信息需要重新读取 | 重新走序列 A 拿新的实例信息 |
| `waitSwitch` | 等待切换（预约了指定时间的正常预约态） | 实例完全正常运行 |
| `switching` | 切换中 | 秒级闪断，客户端要能重连 |
| `restarting` / `upgrading` | 重启中 / 内核版本升级中 | **连接会断**，SQL 会失败，等待即可 |

#### D5. 用 `SwitchTag: 1`（指定时间）时的输入约束

- 起止时间必须**同一天**（`00:00:00` ~ `23:59:59`），**不支持跨天**
- 起止间隔要**大于 30 分钟**、且**不超过 2 小时**
- 到点前实例处于 `waitSwitch`（完全正常）；到点后进入 `switching`，同样是一次闪断

按这个范围给时间参数最稳；拿不准就用 `SwitchTag: 0` 立即切换，绕开时间参数。

## 踩坑清单

| 坑 | 现象 | 正确做法 |
| --- | --- | --- |
| 两个变配接口的时间格式不同 | 照 B1 的格式往 `UpgradePGInstanceToDedicated` 填、或反过来，报参数格式错 | `ModifyPGInstanceSpec` 用 `YYYY-MM-dd HH:mm:ss`，`UpgradePGInstanceToDedicated` 用 `HH:MM:SS`；不确定就用 `SwitchTag: 0` 立即切换，绕开时间参数 |
| 内存单位在两处不一样 | 顺手把 `DescribeClasses.ClassInfoSet[].Memory` 填进 `ModifyPGInstanceSpec.Memory` | 规格表的 `Memory` 是 **MB**，要先除以 1024 换算成 GB（同一规格两处实测为 2048 与 2） |
| 提交了不在售的规格 | `spec 3C3G is not available in region ap-shanghai` | 先跑步骤 3 / 6 拿 `ClassInfoSet`，从列表里挑 `SpecCode` / `CPU` / `Memory`；不要凭经验凑核数与内存 |
| 把 `DescribeTaskResult` 回查变配 | `Task not found.` | `ModifyPGInstanceSpec` 不返回任何任务号；变配的进度走步骤 9 的 `postgres/DescribeTasks`，规格是否生效走步骤 10。只有 `UpgradePGInstanceToDedicated` 返回 `TaskId`，也只用步骤 8 查它 |
| `SwitchTag` 在「入参」与「任务详情」里是两套枚举 | 入参传 `SwitchTag: 0`（立即切换），回来在 `DescribeTasks` 里看到 `TaskDetail.SwitchTag: 1`（实测），据此以为自己传错了 | 入参：`ModifyPGInstanceSpec` 是 `0` 立即 / `1` 指定时间 / `2` 维护窗口，`UpgradePGInstanceToDedicated` 是 `0` 立即 / `1` 指定时间（**没有 2**）；PG 任务详情里的 `TaskDetail.SwitchTag` 是另一套：`0` 不需要切换 / `1` 立即 / `2` 指定时间 / `3` 维护窗口。两套不要互相校验 |
| 把 `TaskDetail.AllSteps` 当固定清单 | 第一次读到 4 步、过一会儿读到 5 步，以为数据错乱 | `AllSteps` / `CurrentStep` 随任务推进动态生成。判断完成只看 `Status` 与 `Progress` |
| 拿别的任务的 `Progress` 当变配进度 | 读到 `ModifyInstanceParams` 那条的 `Progress: 100`，误判变配已完成 | `TaskSet` 是混排的，先按 `TaskType = "ModifyInstanceSpec"` 且 `StartTime` 最晚筛出本次任务，再读 `Progress` |
| 以为有人能给出「预计完成时间」 | 在 `DescribeTaskResult` / `DescribeTasks` 里找 ETA 字段，找不到 | 没有这个字段。按序列 D2 给：当前 `Progress` + 同实例历史同类任务的 `EndTime - StartTime`；别自己估一个分钟数报给用户 |
| 变配后主备角色会互换 | 变配完成后 `DBNodeSet` 里的 `Primary` 与 `Zone` 跟变配前不同，被当成"变配没生效"或"实例换了" | 变配过程会临时多出一个备节点、完成后主备互换。判断生效只看 `DBInstanceCpu` / `DBInstanceMemory` / `DBInstanceStorage` 与 `UpdateTime`，不要拿 `Zone` / 主备角色当判据 |
| 把变配期间当「不可用」 | 提前告诉用户"数据库会中断几分钟"，用户白等 | 只有最终切换是**秒级闪断**，迁移期间连接正常、SQL 照跑。按序列 D1 的三段口径说 |
| 想从 `switching` 分辨是升配还是升独享 | 看到实例处于 `switching`，据此推断"在做哪一种变更" | 控制台代码里注明：`switching` 被**升配（独享）与升独享（共享）共用，且新旧实例可能共用 ID，前端无法可靠区分**，所以一律按"不可操作"处理。要分辨就回查 `DescribeTasks` 里那条任务的类型与起点时间，别猜 |
| 翻不到更早的变配记录 | `DescribeTasks` 里只有近期任务 | 不传 `MinStartTime` 时默认只回 **180 天内**；`Limit` 上限 `100`，要更多就翻页 |
| 漏传 `DescribeTaskResult` 的入参 | 缺 `EnvId` 报 `The request is missing the required parameter \`EnvId\`.`，补齐后又报缺 `TaskId` | 入参只有 `EnvId` + `TaskId` 两个；`TaskType` 是返回字段、不是入参，不要往请求里塞 |
| 用 `TaskType` 做白名单过滤 | 按文档枚举只认 `PGUserMigration`，升独享的任务被当成"查不到" | `TaskType` 的文档枚举不含升级任务；判读只看 `Status` / `Phase` / `Reason`，不要去匹配 `TaskType` 的取值 |
| 在共享实例上直接调调规格接口 | `FailedOperation.InstanceStatusConflict`（Instance status does not match the required status for this operation） | 先看步骤 1 的 `TenantType`：`SHARED` 先走 B2 升独享，变 `DEDICATED` 之后再走 B1 调规格。升独享是单向的 |
| `Region` 传错位置 | `Region is not recognized`（`tcb` 的这几个接口文档注明「本接口不需要传递此参数」） | `tcb` 的变配族把地域交给环境绑定；`postgres` 的读接口要地域，且必须在 `callCloudApi` **顶层** `region` 传，不要写进 `params` |
| 账号级登录仍被拦 | 首个调用返回 `ENV_REQUIRED`（「当前已登录，但尚未绑定环境」） | 先 `auth(action="set_env", envId=…)` 绑定目标环境 |
| 在独享实例上试升独享 | `only shared (multi-tenant) instance can be upgraded to dedicated, current form: small_tenant` | 这是「不适用」，不是「升级失败」。先用步骤 1 的 `TenantType` 判断：`DEDICATED` 的实例根本没有升独享这回事，如实告诉用户不需要升 |
| 把"提交成功"当成"已完成" | 变配 / 升独享提交后立刻去连库，规格还是旧的 | 两个入口都是异步：升独享按序列 C 步骤 8 轮询 `Status`，调规格先按步骤 9 看 `Progress`、再按步骤 10 比对规格字段与 `UpdateTime` |
| 选了与当前相同的规格 | 前端提示「请选择与当前不同的规格」、提交按钮点不动；绕过界面直接提交，接口回 `unchanged` | 这是**没发生变更**，不是变配成功：既不产生订单、也不产生任务，别拿它去轮询进度或复查规格。提交前先把目标规格与现状比一遍（见「验证步骤」第 3 条） |
| 以为变配要先升级套餐 | 用户问「是不是得先升套餐才能调规格 / 升独享」，于是先去推套餐、改计费模式 | 分开答：**B1 调规格没有套餐前置**，只看实例状态与规格合法性；**B2 升独享必须有套餐准入**（标准版及以上 / 集成版 / 平台版），个人版实测被拒。两者都按实例规格扣资源点（342 资源点/CU/小时 + 0.5 资源点/GB/小时），只有资源点扣不够时才需要加购资源包 —— 那是额度问题。详见「费用与套餐」一节 |
| 用 `ResourceLimit` 或 `PackageType` 判断某套餐能否升独享 | 看到个人版 `ResourceLimit` 里没有 `PostgreSQL.DedicatedInstance` 键，就认定「没这个键 = 不能升」 | 这个判据不成立：标准版同样没有该键也能升（有键的只有企业版 / 企业高级版）。`PackageType` 也不可靠（`DescribeEnvPlans` 与 `listPackages` 对同档位口径不一致）。**只能直接调接口看返回** |
| 把三类报错混成一句「套餐不行」 | 在没开 PG 的环境上调 B2 拿到 `PG instance not found.`，据此断言套餐不支持 | 校验顺序是**先实例、后套餐**。三种报错对应三种原因，见序列 B2 的「报错读法」表 |
| 用「新开的环境就是独享」省掉序列 A | 以为新开的云开发 PG 都是独享，跳过序列 A 直接调 B2 | 实测 2026-10-16 新建的标准版环境 PG 仍是 `SHARED`。**一律先跑序列 A 看 `TenantType`** |
| 把升独享的收尾态当失败 | 任务 `Succeed` 之后实例还在 `rest-accessible` / `log-switching`，或看到端点从 `jnsgw` 虚拟地址变成私有地址，以为出问题了 | 这是正常收尾。判完成只看 `DBInstanceCpu` / `DBInstanceMemory` / `DBInstanceStorage` 与 `UpdateTime`，见序列 B2 的「任务与耗时」 |
| 以为升独享必然换实例 ID | 按「一定换 ID」去重跑序列 A，结果白跑 | 实测**不必然换**（`new_instance_id == instance_id`，全程没出现 `migrated`）。会变的是 `CreateTime`（变成提交时刻，说明新实例复用同名 ID）。只有用旧 ID 查到过期信息时才重走序列 A |
| 找错控制台入口 | 在环境设置页 `#/env/env-setting` 里翻实例规格 | 规格在 PG 实例页 `#/db/postgres/setting`；任务列表在 `#/db/postgres/tasks`。`#/db/mysql/setting` 是 MySQL 的页，两者不通用 |

## 验证步骤

1. **序列 A**：`DescribeEnvInfo` 返回的 `EnvBaseInfo.PostgreSQL` 非空，取到 `InstanceName`；`DescribeDBInstanceAttribute` 能按它查到 `DBInstanceStatus = running`。查不到就先确认环境是否真的开通了 PG。
2. **序列 B 选规格**：目标 CPU / 内存能在 `ClassInfoSet` 里找到同一行，`State = 1`，且目标存储落在该行 `MinStorage` ~ `MaxStorage` 之间。找不到就别提交。
3. **序列 B 比对现状**：拿步骤 2 的 `DBInstanceCpu` / `DBInstanceMemory` 与步骤 3 选中的目标规格比一遍。**与当前完全一致就停手** —— 接口对「目标 = 现状」回 `unchanged`，既不产生订单、也不产生任务，不要提交完再去轮询任务。只有目标确实不同才继续。
4. **序列 B 预检**：步骤 4 的 `DryRun: true` **没有报错**即为通过；返回的 `DealName` / `BillId` 为空串表示没有产生订单。报错就改参数重来。
5. **序列 B 正式提交后看进度**：返回 `DealName` / `BillId` 非空只代表订单已受理。立刻用步骤 9 查一次 —— `TaskSet` 里应出现一条新的 `TaskType = "ModifyInstanceSpec"`、`StartTime` 最晚的任务，且 `Status` 为运行中。一分钟后再查，`Progress` 应向前推进。查不到新任务就先确认 `DBInstanceId` 与地域传对。
6. **序列 B 正式提交后回查规格**：步骤 10 返回的 `DBInstanceCpu` / `DBInstanceMemory` / `DBInstanceStorage` 等于目标值，且 `UpdateTime` 晚于提交时间，**这三项都对上才算变配完成**（不要拿 `Zone` 或主备角色当判据）。同时步骤 9 里那条任务的 `Status` 应为 `Success`、`Progress = 100`、`EndTime` 非空。
7. **序列 B2（先确认两个前提）**：先看**套餐**（须为标准版及以上 / 集成版 / 平台版，个人版会被拒 `current package does not support upgrading to dedicated instance`），再看**步骤 1 的 `TenantType`** 必须是 `SHARED`（不是就直接停手；实测 `DEDICATED` 的实例会报 `current form: small_tenant`）。环境若压根没开 PG，接口先报 `PG instance not found.` —— 那是没开通 PG，不是套餐问题。满足时 `UpgradePGInstanceToDedicated` 返回的 `TaskId` 非空；步骤 8 轮询到 `Status = Succeed` **还不是终点** —— 再按步骤 10 确认 CPU / 内存已是目标规格（云开发任务成功不等于 PG 升级完成），`Failed` 时读 `Reason` 定位。完成后重走步骤 1，`TenantType` 应变为 `DEDICATED`；实例 ID **不必然变**（实测 `new_instance_id == instance_id`），只有用旧 ID 查到过期信息时才重新 `DescribeEnvInfo` 取新 ID。
8. 全链路的读步骤只调用 `Describe*`；写操作只有 B1 / B2 两处，各自提交前先确认真实目标环境。
